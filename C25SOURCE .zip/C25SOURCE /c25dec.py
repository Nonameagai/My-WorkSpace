den='[1;90m'
luc='[1;32m'
trang='[1;37m'
red='[1;31m'
vang='[1;33m'
tim='[1;35m'
lamd='[1;34m'
lam='[1;36m'
purple='\331[35m'
hong='[1;95m'
lam = "\033[1;36m"
hong = "\033[1;95m"
luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
xnhac = "\033[1;36m"

thanh_xau=trang+'~'+red+'['+vang+'C25'+red+'] '+trang+'➩ '+luc
thanh_dep=trang+'~'+red+'['+luc+'C25'+red+'] '+trang+'➩ '+luc

import requests,json,os,sys
from sys import platform
from datetime import datetime        
from time import sleep,strftime
try:from pystyle import Add,Center,Anime,Colors,Colorate,Write,System
except:os.system('pip install pystyle','pip install bs4', 'pip install requests', 'pip install colorama', 'pip install beautifulsoup4', 'pip install Anime', 'pip install webdriver_manager', 'pip install selenium ', 'pip install mechanize'); from pystyle import Add,Center,Anime,Colors,Colorate,Write,System

banners=f"""
╔═════════════════════════════════════════════════════════════════           
 ██████╗██████╗ ███████╗    ████████╗ ██████╗  ██████╗ ██╗     
██╔════╝╚════██╗██╔════╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
██║      █████╔╝███████╗       ██║   ██║   ██║██║   ██║██║     
██║     ██╔═══╝ ╚════██║       ██║   ██║   ██║██║   ██║██║     
╚██████╗███████╗███████║       ██║   ╚██████╔╝╚██████╔╝███████╗
 ╚═════╝╚══════╝╚══════╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
╠═════════════════════════════════════════════════════════════════
║➢ Admin      : Vũ Văn Chiến                                   
║➢ Youtube    : https://www.youtube.com/@c25tool                  
║➣ Nhóm Bot Zalo :  https://zalo.me/g/elcygl942              
║➣ Website    :  c25tool.net            
╚═════════════════════════════════════════════════════════════════
"""
thongtin=f"""
Vượt Link Để lấy Key Free Hoặc Mua Key Vip Tại Web: C25TOOL.NET
Lưu ý :(key free đổi theo ip máy nên lần sau vào tool không thay wifi nhé)
"""

def lovec25(so):
    a='────'*so
    for i in range(len(a)):
        sys.stdout.write(a[i])
        sys.stdout.flush()
        sleep(0.003)
    print()

def clear():
    if platform[0:3]=='lin':
        os.system('clear')
    else:
        os.system('cls')

def banner():
    print('[0m',end='')
    clear()
    a=Colorate.Horizontal(Colors.blue_to_green,banners)
    for i in range(len(a)):
        sys.stdout.write(a[i])
        sys.stdout.flush()
    print()
    print(thongtin)

banner()

print(f"""{luc}┏━━━━━━━━━━━━━━━━━━━━━━━┓
{vang}┃   {vang}Tool Cày Cuốc  {vang}     ┃
{lam}┗━━━━━━━━━━━━━━━━━━━━━━━┛ """)
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}1.1{lam}] {lam}Tool Cày Xu TDS Tiktok')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}1.2{lam}] {lam}Tool Cày Xu TDS Instagram')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}1.3{lam}] {lam}Tool Golike TikTok [ADR]')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}1.4{lam}] {lam}Tool Golike Instagram')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}1.5{lam}] {lam}Tool Cày Xu TDS Facebook')
print(f'{luc}{lam}────────────────────────────────────────────────────────')
print(f"""{luc}┏━━━━━━━━━━━━━━━━━━━━━━━┓
{vang}┃  {vang}Tool Profile         {vang}┃
{lam}┗━━━━━━━━━━━━━━━━━━━━━━━┛""")
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}2.1{lam}] {lam}Tool Buff Share Ảo Cookie ')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}2.2{lam}] {lam}Tool Get Token Facebook 16 Loại')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}2.3{lam}] {lam}Tool Lấy ID Bài Viết, ID Facebook')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}2.4{lam}] {lam}Tool CMT Bài Viết Dạo Facebook[bảo trì]')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}2.5{lam}] {lam}Tool Get Cookie Facebook Bằng TK MK')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}2.6{lam}] {lam}Tool Spam Tin Nhắn, War Messenger')
print(f'{luc}{lam}────────────────────────────────────────────────────────')
print(f"""{luc}┏━━━━━━━━━━━━━━━━━━━━━━━┓
{vang}┃   {vang}Tool Tiện Ích       {vang}┃
{lam}┗━━━━━━━━━━━━━━━━━━━━━━━┛""")
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.1{lam}] {lam}Tool Doss Web + Doss IP')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.2{lam}] {lam}Tool Get Proxy')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.3{lam}] {lam}Tool Lọc Proxy')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.4{lam}] {lam}Tool Scan Mail Ảo Lấy Mã')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.5{lam}] {lam}Tool Spam SĐT')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.6{lam}] {lam}Tool Buff Tiktok [PC]')
print(f'{thanh_xau}{luc}Nhập {luc}[{vang}3.7{lam}] {lam}Tool Reg Nick FB')
print(f'───────────────────────────────────────────────────────────────────')
chon=input(f'{thanh_xau}{do}Nhập Số: {vang}')
try:
    folder = chon.split(".")[0]
    filename = f"{chon}.py"
    filepath = os.path.join("C25", folder, filename)
    if not os.path.exists(filepath):
        print(red + f"Không tìm thấy file: {filepath}")
    else:
        with open(filepath, "r", encoding="utf-8") as f:
            exec(f.read())
except Exception as e:
    print(red + f"Lỗi khi thực thi file: {e}")
exit(print("Lựa chọn sai"))